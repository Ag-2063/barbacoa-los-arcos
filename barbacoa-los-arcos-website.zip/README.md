# Barbacoa Los Arcos — sitio web del menú

Este sitio está hecho con HTML y CSS, por lo que puedes publicarlo gratis con GitHub Pages.

## Archivos
- `index.html`: texto y secciones del menú.
- `style.css`: colores, diseño adaptable a celular y escritorio.
- `script.js`: pequeño detalle de navegación.
- `assets/`: imágenes originales del menú como referencia.

## Cómo publicarlo en GitHub Pages
1. Entra a https://github.com e inicia sesión.
2. Haz clic en **New repository**. Ponle un nombre como `barbacoa-los-arcos-menu`.
3. Selecciona **Public** y crea el repositorio.
4. Descomprime este ZIP en tu computadora.
5. Dentro del repositorio, usa **Add file → Upload files** y sube `index.html`, `style.css`, `script.js` y la carpeta `assets`.
   - Importante: `index.html` debe quedar en la raíz del repositorio, no dentro de otra carpeta.
6. Haz clic en **Commit changes**.
7. En el repositorio abre **Settings → Pages**.
8. En **Build and deployment**, elige **Deploy from a branch**; selecciona `main` y `/ (root)`, y guarda.
9. Espera un momento. GitHub mostrará la dirección pública del sitio en esa misma sección.

## Antes de publicarlo
Revisa el texto del menú: en el diseño original hay algunas palabras que pueden necesitar confirmación (por ejemplo, “Tuna pieza”, los sabores de paletas y el precio de limonada/naranjada). También puedes reemplazar el teléfono o redes sociales si cambian.

## Editar el menú
Abre `index.html` y busca el producto. Cambia el nombre o el precio dentro de la etiqueta correspondiente, guarda y vuelve a subir el archivo a GitHub.
