// El menú funciona sin JavaScript; este archivo deja listo el espacio para futuras mejoras.
document.querySelectorAll('.menu-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.menu-nav a').forEach((item) => item.removeAttribute('aria-current'));
    link.setAttribute('aria-current', 'location');
  });
});
